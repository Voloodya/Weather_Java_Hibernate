CREATE PROCEDURE AVG_t_naselen_punkt()
  BEGIN
SELECT Name_country, Name_naselen_punkt, AVG(t_day)
from pogoda JOIN naselennay_punkt ON pogoda.id_punkt=naselennay_punkt.id_punkt
JOIN country ON country.id_country=naselennay_punkt.id_country
JOIN climat_poyas ON climat_poyas.id_poyas=naselennay_punkt.id_poyas
group by climat_poyas.id_poyas;
END;
