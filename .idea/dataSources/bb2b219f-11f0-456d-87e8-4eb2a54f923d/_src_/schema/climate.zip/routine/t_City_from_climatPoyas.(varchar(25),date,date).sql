CREATE PROCEDURE t_City_from_climatPoyas(IN poyas VARCHAR(25), IN data1 DATE, IN data2 DATE)
  BEGIN
SELECT Name_climate_poyas, Name_country, Name_naselen_punkt, t_day 
from pogoda JOIN naselennay_punkt ON pogoda.id_punkt=naselennay_punkt.id_punkt
JOIN country ON country.id_country=naselennay_punkt.id_country
JOIN region ON country.id_region=region.id_region
JOIN climat_poyas ON climat_poyas.id_poyas=naselennay_punkt.id_poyas
WHERE Name_climate_poyas=poyas AND
Data_ BETWEEN data1 AND data2;
END;
