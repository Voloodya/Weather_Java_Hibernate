CREATE PROCEDURE AVG_t_day_poyas()
  BEGIN
SELECT Name_climate_poyas, AVG(t_day)
from pogoda JOIN naselennay_punkt ON pogoda.id_punkt=naselennay_punkt.id_punkt
JOIN climat_poyas ON climat_poyas.id_poyas=naselennay_punkt.id_poyas
group by climat_poyas.id_poyas;
END;
