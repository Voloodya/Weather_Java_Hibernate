CREATE PROCEDURE t_day_in_city(IN m INT, IN data1 DATE, IN data2 DATE)
  BEGIN
SELECT naselennay_punkt.Name_naselen_punkt, pogoda.Data_,pogoda.t_day FROM climate.pogoda
JOIN naselennay_punkt USING(id_punkt)
WHERE pogoda.t_day<m AND
Data_ BETWEEN data1 AND data2;
END;

